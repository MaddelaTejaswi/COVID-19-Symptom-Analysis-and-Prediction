/**
What are the top three most prevalent COVID-19 symptoms reported in the dataset,
and what is the distribution of symptom severity among them?
*/
SELECT 
    CASE
        WHEN FEVER = 1 THEN 'Fever'
        WHEN TIREDNESS = 1 THEN 'Tiredness'
        WHEN DRY_COUGH = 1 THEN 'Dry Cough'
        WHEN DIFFICULTY_IN_BREATHING = 1 THEN 'Difficulty in Breathing'
        WHEN SORE_THROAT = 1 THEN 'Sore Throat'
        WHEN PAINS = 1 THEN 'Pains'
        WHEN NASAL_CONGESTION = 1 THEN 'Nasal Congestion'
        WHEN RUNNY_NOSE = 1 THEN 'Runny Nose'
        WHEN DIARRHEA = 1 THEN 'Diarrhea'
        ELSE 'None'
    END AS Symptom,
    COUNT(*) AS Total_Cases,
    SUM(CASE WHEN SEVERITY_MILD = 1 THEN 1 ELSE 0 END) AS Mild,
    SUM(CASE WHEN SEVERITY_MODERATE = 1 THEN 1 ELSE 0 END) AS Moderate,
    SUM(CASE WHEN SEVERITY_SEVERE = 1 THEN 1 ELSE 0 END) AS Severe
FROM 
    COVID_DATA
GROUP BY 
    FEVER,
    TIREDNESS,
    DRY_COUGH,
    DIFFICULTY_IN_BREATHING,
    SORE_THROAT,
    PAINS,
    NASAL_CONGESTION,
    RUNNY_NOSE,
    DIARRHEA
ORDER BY 
    Total_Cases DESC
FETCH FIRST 3 ROWS ONLY;

/**
How do the reported COVID-19 symptoms vary month over month, and are there 
any noticeable seasonal patterns in their prevalence?
*/
SELECT 
    'Fever' AS Symptom,
    SUM(FEVER) AS Total_Cases
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Tiredness' AS Symptom,
    SUM(TIREDNESS) AS Total_Cases
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Dry Cough' AS Symptom,
    SUM(DRY_COUGH) AS Total_Cases
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Difficulty in Breathing' AS Symptom,
    SUM(DIFFICULTY_IN_BREATHING) AS Total_Cases
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Sore Throat' AS Symptom,
    SUM(SORE_THROAT) AS Total_Cases
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Pains' AS Symptom,
    SUM(PAINS) AS Total_Cases
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Nasal Congestion' AS Symptom,
    SUM(NASAL_CONGESTION) AS Total_Cases
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Runny Nose' AS Symptom,
    SUM(RUNNY_NOSE) AS Total_Cases
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Diarrhea' AS Symptom,
    SUM(DIARRHEA) AS Total_Cases
FROM 
    COVID_DATA;
    
/**
What is the correlation between certain COVID-19 symptoms and the age group 
where these symptoms were most prevalent? Provide insights into which age groups
commonly experience specific symptoms.
*/
SELECT 
    'Fever' AS Symptom,
    'AGE_0_9' AS Age_Group,
    SUM(FEVER) AS Symptom_Count
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Fever' AS Symptom,
    'AGE_10_19' AS Age_Group,
    SUM(FEVER) AS Symptom_Count
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Fever' AS Symptom,
    'AGE_20_24' AS Age_Group,
    SUM(FEVER) AS Symptom_Count
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Fever' AS Symptom,
    'AGE_25_59' AS Age_Group,
    SUM(FEVER) AS Symptom_Count
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Fever' AS Symptom,
    'AGE_60PLUS' AS Age_Group,
    SUM(FEVER) AS Symptom_Count
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Tiredness' AS Symptom,
    'AGE_0_9' AS Age_Group,
    SUM(TIREDNESS) AS Symptom_Count
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Tiredness' AS Symptom,
    'AGE_10_19' AS Age_Group,
    SUM(TIREDNESS) AS Symptom_Count
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Tiredness' AS Symptom,
    'AGE_20_24' AS Age_Group,
    SUM(TIREDNESS) AS Symptom_Count
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Tiredness' AS Symptom,
    'AGE_25_59' AS Age_Group,
    SUM(TIREDNESS) AS Symptom_Count
FROM 
    COVID_DATA
UNION ALL
SELECT 
    'Tiredness' AS Symptom,
    'AGE_60PLUS' AS Age_Group,
    SUM(TIREDNESS) AS Symptom_Count
FROM 
    COVID_DATA
ORDER BY 
    Symptom, Age_Group;

/**
Are there any clusters of symptoms that commonly occur together among 
individuals and how does the severity of symptoms correlate with their prevalence.
*/
WITH SymptomData AS (
    SELECT 
        DIFFICULTY_IN_BREATHING,
        SORE_THROAT,
        NONE_SYMPTON,
        PAINS,
        NASAL_CONGESTION,
        RUNNY_NOSE,
        DIARRHEA,
        NONE_EXPERIENCING,
        AGE_0_9,
        AGE_10_19,
        AGE_20_24,
        AGE_25_59,
        AGE_60PLUS,
        GENDER_FEMALE,
        GENDER_MALE,
        GENDER_TRANSGENDER,
        SEVERITY_MILD,
        SEVERITY_MODERATE,
        SEVERITY_NONE,
        SEVERITY_SEVERE
    FROM COVID_DATA
)
SELECT
    SYMPTOMS,
    COUNT(*) AS SYMPTOMS_OCCURRENCE,
    AVG(SEVERITY_MILD + SEVERITY_MODERATE + SEVERITY_SEVERE) AS AVERAGE_SEVERITY
FROM (
    SELECT
        CASE
            WHEN DIFFICULTY_IN_BREATHING > 0 THEN 'DIFFICULTY_IN_BREATHING'
            WHEN SORE_THROAT > 0 THEN 'SORE_THROAT'
            WHEN NONE_SYMPTON > 0 THEN 'NONE_SYMPTON'
            WHEN PAINS > 0 THEN 'PAINS'
            WHEN NASAL_CONGESTION > 0 THEN 'NASAL_CONGESTION'
            WHEN RUNNY_NOSE > 0 THEN 'RUNNY_NOSE'
            WHEN DIARRHEA > 0 THEN 'DIARRHEA'
            WHEN NONE_EXPERIENCING > 0 THEN 'NONE_EXPERIENCING'
            ELSE 'OTHERS'
        END AS SYMPTOMS,
        SEVERITY_MILD,
        SEVERITY_MODERATE,
        SEVERITY_SEVERE
    FROM SymptomData
) SymptomsWithSeverity
GROUP BY SYMPTOMS
ORDER BY SYMPTOMS_OCCURRENCE DESC;

/**
Is there a significant difference in the prevalence of COVID-19 infection among 
individuals reporting fever, cough, and loss of taste and smell compared to 
those not reporting these symptoms?
*/
SELECT 
    SUM(CASE WHEN FEVER = 1 AND DRY_COUGH = 1 AND (SORE_THROAT = 1 OR NASAL_CONGESTION = 1) THEN 1 ELSE 0 END) AS symptomatic_infected,
    SUM(CASE WHEN FEVER = 0 AND DRY_COUGH = 0 AND (SORE_THROAT = 0 OR NASAL_CONGESTION = 0) THEN 1 ELSE 0 END) AS asymptomatic_infected,
    COUNT(*) AS total_population
FROM 
    COVID_DATA;
    
/**
Which geographical region has the highest prevalence of reported COVID-19 
symptoms, and are there any noticeable variations in symptom distribution 
across different regions?
*/
SELECT 
    COUNTRY,
    SUM(FEVER) AS fever_count,
    SUM(DRY_COUGH) AS dry_cough_count,
    SUM(SORE_THROAT) AS sore_throat_count,
    SUM(NASAL_CONGESTION) AS nasal_congestion_count,
    SUM(DIFFICULTY_IN_BREATHING) AS breathing_difficulty_count,
    SUM(TIREDNESS) AS tiredness_count,
    SUM(DIARRHEA) AS diarrhea_count,
    SUM(RUNNY_NOSE) AS runny_nose_count,
    SUM(PAINS) AS pains_count
FROM 
    COVID_DATA
GROUP BY 
    COUNTRY
ORDER BY 
    SUM(FEVER + DRY_COUGH + SORE_THROAT + NASAL_CONGESTION + DIFFICULTY_IN_BREATHING + TIREDNESS + DIARRHEA + RUNNY_NOSE + PAINS) DESC;


/**
How does the prevalence of COVID-19 symptoms vary across different geographic 
locations?
*/
SELECT 
    COUNTRY,
    ROUND(SUM(FEVER) / COUNT(*) * 100, 2) AS fever_prevalence,
    ROUND(SUM(DRY_COUGH) / COUNT(*) * 100, 2) AS dry_cough_prevalence,
    ROUND(SUM(SORE_THROAT) / COUNT(*) * 100, 2) AS sore_throat_prevalence,
    ROUND(SUM(NASAL_CONGESTION) / COUNT(*) * 100, 2) AS nasal_congestion_prevalence,
    ROUND(SUM(DIFFICULTY_IN_BREATHING) / COUNT(*) * 100, 2) AS breathing_difficulty_prevalence,
    ROUND(SUM(TIREDNESS) / COUNT(*) * 100, 2) AS tiredness_prevalence,
    ROUND(SUM(DIARRHEA) / COUNT(*) * 100, 2) AS diarrhea_prevalence,
    ROUND(SUM(RUNNY_NOSE) / COUNT(*) * 100, 2) AS runny_nose_prevalence,
    ROUND(SUM(PAINS) / COUNT(*) * 100, 2) AS pains_prevalence
FROM 
    COVID_DATA
GROUP BY 
    COUNTRY
ORDER BY 
    COUNTRY;

/**
What are the most common pre-existing health conditions among individuals 
reporting severe COVID-19 symptoms, and is there a correlation between exposure
to infected individuals and the severity of reported symptoms?
*/
SELECT 
    SUM(CASE WHEN SEVERITY_SEVERE = 1 THEN 1 ELSE 0 END) AS severe_cases,
    SUM(CASE WHEN SEVERITY_SEVERE = 1 THEN 1 ELSE 0 END) AS common_preexisting_conditions,
    SUM(CONTACT_YES) AS exposed_to_infected,
    SUM(CASE WHEN SEVERITY_SEVERE = 1 AND CONTACT_YES = 1 THEN 1 ELSE 0 END) AS severe_symptoms_with_exposure,
    COUNT(*) AS total_population
FROM 
    COVID_DATA;








